﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entities.Products
{
    class HardDrive : StorageMaster.Product
    {
        public HardDrive(double price) : base(price, 1d)
        {
        }
    }
}
