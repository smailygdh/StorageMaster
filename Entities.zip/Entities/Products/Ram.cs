﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entities.Products
{
    public class Ram : StorageMaster.Product
    {
        public Ram(double price) : base(price, 0.1)
        {
            
        }
    }
}
