﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entities.Products
{
    public class SolidStateDrive : StorageMaster.Product
    {
        public SolidStateDrive(double price) : base(price, 0.2)
        {
        }
    }
}
