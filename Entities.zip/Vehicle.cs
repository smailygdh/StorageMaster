﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StorageMaster
{
    public abstract class Vehicle
    {
        private int capacity;
        private List<Product> trunk = new List<Product>();

        protected Vehicle(int capacity)
        {
            this.Capacity = capacity;
        }

        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }

        public IReadOnlyCollection<Product> Trunk
        {
            get
            {
                return trunk;
            }
            private set
            {

            }
        }

        public bool IsFull
        {
            get
            {
                if (this.Trunk.Sum(p => p.Weight) >= this.Capacity)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool IsEmpty
        {
            get
            {
                if (this.Trunk.Any())
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public void LoadProduct(Product product)
        {
            if (IsFull)
            {
                Console.WriteLine(ErrorMesages.VehicleIsFull);
            }
            else
            {
                this.trunk.Add(product);
            }
        }

        public Product Unload()
        {
            if (IsEmpty)
            {
                Console.WriteLine(ErrorMesages.VehicleNoProduct);

            }
            // else
            //  {
            var lastProduct = this.trunk.Last();
            return lastProduct;
            // }

        }
    }
}
