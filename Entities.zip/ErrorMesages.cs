﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster
{
   public static class ErrorMesages
    {
        public static string Price => "Price cannot be negative!";

        public static string VehicleIsFull => "Vehicle is full";

        public static string VehicleNoProduct => "No products left in vehicle!";
    }
}
