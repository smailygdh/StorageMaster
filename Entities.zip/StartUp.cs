﻿using StorageMaster.Entities.Products;
using StorageMaster.Entities.Vehicles;
using System;

namespace StorageMaster
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           // Console.WriteLine("Hello World!");
            var ram = new Ram(10);
            var gpu = new Gpu(5);
            Console.WriteLine(ram.Weight);
            var van = new Van();
            van.LoadProduct(ram);
            van.LoadProduct(gpu);
            Console.WriteLine(van);
        }
    }
}
