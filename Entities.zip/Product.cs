﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster
{
    public abstract class Product
    {
        private double price;
        private double weight;

        protected Product(double price, double weight)
        {
            this.Price = price;
            this.Weight = weight;
        }

        public double Weight
        {
            get { return weight; }
            set { weight = value; }
        }


        public double Price
        {
            get { return price; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine(ErrorMesages.Price);
                }
                price = value;
            }
        }

    }
}
